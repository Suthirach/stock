<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>CRUD APP PDO OOP</title>
</head>
<body>
    
    <!-- Add New User Modal Start -->

    <div class="modal fade" tabindex="-1" id="addNewUserModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-header">Add New User</h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                    <div class="modal-body">
                        <form id="add-user-from" class="p-2" novalidate>
                            <div class="row mb-3 gx-3">
                                <div class="col">
                                    <input type="text" name="fname" class="from-control from-control-lg" placeholder="Enter First Name" required>
                                    <div class="invalid-feedback">First name is Required</div>
                                </div>
                                <div class="col">
                                    <input type="text" name="lname" class="from-control from-control-lg" placeholder="Enter last Name" required>
                                    <div class="invalid-feedback">Last name is Required</div>
                                </div>
                                <div class="mb-3">
                                    <input type="text" name="email" class="from-control from-control-lg" placeholder="Enter E-mail" required>
                                    <div class="invalid-feed   back">E-mail is Required</div>
                                </div>
                                <div class="mb-3">
                                    <input type="text" name="phone" class="from-control from-control-lg" placeholder="Enter Phone" required>
                                    <div class="invalid-feedback">Phone is Required</div>
                                </div>
                                <div class="mb-3">
                                    <input type="submit" value="btn-primary btn-block btn-lg" id="add-user-btn" placeholder="Enter E-mail" required>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
    </div>

    <!-- Add New User Model End -->

    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-12 d-flex justify-content-between align-item-center">
                <div>
                    <h4 class="card-body text-primary">All users in the database</h4>
                </div>
                <div>
                    <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#addNewUserModal">Add New User</button>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-lg-12">
                <div id="showAlert"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table tavle table-striped table-boredered text-center">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name/th>
                                <th>Last Namw</th>
                                <th>E-mail</th>
                                <th>Phone</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>

